<div class="fl-page-footer-text fl-page-footer-text-1">
	<span>&copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?></span>
	<span> | </span>
	<span id="fl-site-credits">Powered by <a href="http://www.wpbeaverbuilder.com/?utm_medium=bb-pro&utm_source=bb-theme&utm_campaign=theme-footer" target="_blank" title="WordPress Page Builder Plugin" rel="nofollow noopener">Beaver Builder</a></span>
</div>
