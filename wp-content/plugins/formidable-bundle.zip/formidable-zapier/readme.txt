== Changelog ==
= 1.02 =
* Prevent error when Formidable is disabled
* Use static classes for fields and forms

= 1.01 =
* Order forms by name instead of creation date
* Allow for REDIRECT_HTTP_AUTHORIZATION
* Make sure dates are sent in Y-m-d format for max compatibility
* Get updates from FormidablePro.com

= 1.0 =
* Change created and updated times to user timezone
* Order forms with newest at the top
* Check for saved triggers in a better way
* Support for servers with CGI/FastCGI