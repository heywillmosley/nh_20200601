<table class="form-table">
	<tr class="form-field">
		<td width="200px">
			<label><?php esc_html_e( 'API Key', 'formidable' ); ?></label>
		</td>
		<td>
			<input type="text" class="frm_select_box frm_long_input" value="<?php echo esc_attr( $api_key ); ?>" style="background:transparent;border:none;text-align:left;box-shadow:none;"/>
		</td>
	</tr>
</table>
